# Typing Master & Spell Corrector — Complete V1 UI/UX Handoff

## Purpose
Give GitHub Copilot a concrete UI implementation reference. Use this Markdown as the requirements source and `typing_master_complete_ui_prototype.html` as the interactive visual/flow prototype. The HTML is illustrative, not production logic. Sample names, stats, lessons, and chart values are placeholders.

**Established design direction:** Indigo + Teal, slate neutrals, semantic status colours, Inter/system font stack, light/dark themes.  
**Recommendations needing product confirmation:** guest access, custom text, exact test durations, lesson catalog, achievements, export, monetization.

## Product objective
Help users improve typing speed, accuracy, and consistency through guided lessons, focused practice, timed tests, and understandable progress feedback.

## Primary user flow
```mermaid
flowchart TD
 A[Launch] --> B{Authenticated?}
 B -- Yes --> D[Dashboard]
 B -- No --> C[Sign in / Create account]
 C --> D
 D --> E[Practice]
 D --> F[Lessons]
 D --> G[Typing tests]
 E --> H[Active session]
 F --> H
 G --> H
 H --> I[Finish or timer expires]
 I --> J[Results]
 J --> K[Save session]
 J --> L[Practice again]
 J --> M[Reports]
 D --> M
 D --> N[Profile / Settings]
```

## Route and page inventory
| Route | Page | Purpose | Primary action |
|---|---|---|---|
| `/dashboard` | Dashboard | Orientation and next step | Start practicing |
| `/practice` | Practice workspace | Focused typing session | Finish session |
| `/lessons` | Lessons | Progressive skill learning | Start/continue |
| `/tests` | Typing tests | Timed assessment | Start test |
| `/results/:sessionId` | Results | Session feedback | Practice again |
| `/reports` | Reports | Trends and history | Review/export |
| `/achievements` | Achievements | Milestones | Continue practice |
| `/profile` | Profile | Account and learning goal | Save changes |
| `/settings` | Settings | Theme and practice preferences | Save/persist |
| `/help` | Help & support | FAQs and support form | Submit request |
| `/auth` | Sign in / create account | Account access | Authenticate |
| `/forgot-password` | Password reset | Start password recovery | Send reset |
| `/upgrade` | Optional future plan | Monetization | Only after approval |

## Design system

### Typography
Primary font: `Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`.

| Token | Size / line-height | Weight | Usage |
|---|---|---:|---|
| `display-xl` | 40px / 1.12 | 750 | Hero/onboarding |
| `heading-1` | 32px / 1.2 | 700 | Page titles |
| `heading-2` | 24px / 1.3 | 700 | Major sections |
| `heading-3` | 20px / 1.4 | 650 | Cards/modals |
| `body-lg` | 18px / 1.6 | 400 | Introductory copy |
| `body-md` | 16px / 1.625 | 400 | Default content |
| `body-sm` | 14px / 1.5 | 400 | Supporting copy/tables |
| `label-sm` | 12px / 1.33 | 650 | Field/metric labels |
| `caption` | 12px / 1.5 | 400 | Non-critical metadata |
| `button-md` | 14px / 1.43 | 650 | Buttons |
| `typing` | 20px / 1.8 | 550 | Practice passage; 18px narrow screens |

Use font weights supported by the actual bundled font. Do not use caption styling for critical instructions.

### Colour tokens
Use semantic CSS variables, not scattered literal hex values.

| Token | Light | Dark | Usage |
|---|---|---|---|
| `page` | `#F8FAFC` | `#0B1220` | Canvas |
| `surface` | `#FFFFFF` | `#111827` | Cards, inputs |
| `raised` | `#FFFFFF` | `#1F2937` | Raised surfaces |
| `subtle` | `#F1F5F9` | `#1F2937` | Quiet backgrounds |
| `sunken` | `#E2E8F0` | `#0F172A` | Recessed surface |
| `text-primary` | `#0F172A` | `#F8FAFC` | Headings/key values |
| `text-secondary` | `#475569` | `#CBD5E1` | Descriptions/labels |
| `text-muted` | `#64748B` | `#94A3B8` | Metadata |
| `text-disabled` | `#94A3B8` | `#64748B` | Disabled only |
| `border` | `#E2E8F0` | `#334155` | Outlines |
| `border-strong` | `#CBD5E1` | `#475569` | Strong outlines |
| `brand` | `#4F46E5` | `#818CF8` | Primary action/selection |
| `brand-hover` | `#4338CA` | `#A5B4FC` | Hover |
| `brand-pressed` | `#3730A3` | `#6366F1` | Pressed |
| `teal` | `#0F9D8A` | `#2DD4BF` | Secondary brand/progress |
| `success` | `#15803D` | `#4ADE80` | Correct/success |
| `success-bg` | `#DCFCE7` | `#052E1A` | Success container |
| `error` | `#B91C1C` | `#F87171` | Errors/incorrect |
| `error-bg` | `#FEE2E2` | `#450A0A` | Error container |
| `warning` | `#92400E` | `#FBBF24` | Warnings |
| `warning-bg` | `#FEF3C7` | `#451A03` | Warning container |
| `info` | `#1D4ED8` | `#60A5FA` | Information |
| `info-bg` | `#DBEAFE` | `#172554` | Info container |
| `focus` | `#818CF8` | `#A5B4FC` | Keyboard focus |
| `selection` | `#C7D2FE` | `#3730A3` | Current character |

Typing semantic states:
- Correct: success colour plus non-colour cue where appropriate.
- Incorrect: error colour plus wavy underline/error marker.
- Current: primary text, selection background, visible caret/focus.
- Pending: muted text.
- Corrected: teal plus explicit correction indication.
- Missed/skipped: distinct marker/label, not colour alone.

**Accessibility gate:** measure contrast for every foreground/background combination in both themes and every state. Do not assume every palette pairing passes WCAG AA.

### Layout
- Spacing uses 4px increments: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64.
- Desktop content max-width recommendation: 1200–1240px.
- Sidebar approximately 230–250px desktop.
- Card radius 14–16px; controls 8–10px.
- Card padding 18–20px desktop, 14–16px mobile.
- Breakpoints: 640, 768, 1024, 1280, 1536px.
- Touch targets recommended minimum 44×44px.

## Shared shell and components
Implement reusable: `AppShell`, `SidebarNav`, `MobileNavDrawer`, `TopBar`, `PageHeader`, `Card`, `MetricCard`, `Badge`, `Button`, `TextField`, `SelectField`, `TextArea`, `ProgressBar`, `Tabs`, `DataTable`, `EmptyState`, `InlineAlert`, `Toast`, `ConfirmDialog`, `LoadingSkeleton`.

Desktop: persistent sidebar with Learn/Progress/Account groups; active route visibly highlighted; top bar includes breadcrumb, theme and profile.  
Mobile: sidebar becomes a drawer; close after route selection and on Escape; stack cards; avoid page-level horizontal overflow.

## Page specifications

### 1. Dashboard
**Purpose:** help returning user choose next activity.
- Header greeting/date, title, concise supporting copy.
- Dominant “Start practicing” CTA.
- Metric cards: average WPM, accuracy, practice time, streak.
- Continue-learning card with title, progress, estimated duration, CTA.
- Weekly activity chart with labels and accessible text alternative.
- Quick links: accuracy practice, timed test, learn a key.
- First-use empty state: welcome message and start-first-session CTA; do not show fake zeros.
- Loading skeletons; actionable retry on API error.
- All metrics require units and reporting period.

### 2. Practice workspace
**Purpose:** focused typing session.
- Tabs: Free practice, Guided drills, Custom text (custom text is proposed; confirm scope).
- Session metadata: duration, goal, difficulty.
- Passage renderer supports correct, incorrect, current, pending, corrected, missed.
- Text input is labelled; disable spellcheck, autocorrect and autocapitalize for capture.
- Live metrics: WPM, accuracy, progress.
- Controls: finish, restart, hint; settings for duration/difficulty.
- Mobile stacks metrics and passage.
- Timer should start on first meaningful input or explicit Start—not simply on page view.
- Finish and restart with meaningful progress require confirmation.
- Timer expiry auto-finalizes and routes to results.
- Define paste policy separately for free practice, custom text and tests.
- Decide pause/resume and recovery requirements; do not display unsupported controls.
- Handle offline/failed save and unsaved-session warning.

### 3. Lessons
- Show learning paths/lesson cards, description, lesson count, status and progress.
- Status: Not started, In progress, Completed, Locked only if prerequisites exist.
- CTA varies: Start, Continue, Review.
- Explain prerequisites for locked content.
- Empty and loading/error states.
- Lesson player should reuse Practice session engine with lesson-specific metadata/instructions.

### 4. Typing tests
- Proposed durations: 1, 3, 5 minutes; configurable pending confirmation.
- Explain test rules before start.
- Start creates test session and enters shared practice engine in test mode.
- Abandon confirmation; auto-submit at timer expiry.
- Results identify test mode and its configuration.

### 5. Results
- Completion heading.
- Summary: clearly labelled gross/net WPM, accuracy, correct characters/errors, duration.
- Strengths and one or two actionable focus areas.
- Recommended next practice.
- Actions: practice again, reports, dashboard, save if not automatically persisted.
- Load by session ID; handle missing session.
- Never claim saved unless server confirms; retry on failure.

### 6. Reports
- Period selector (week/month/90 days are recommendations).
- Average WPM, average accuracy, sessions completed.
- Speed and accuracy trend charts with units, axes, legends, and accessible text summaries.
- Recent sessions table: date, mode, WPM, accuracy, duration.
- Export only when a real endpoint/file flow exists.
- Empty state CTA to practice; loading skeleton and retryable errors.

### 7. Achievements
- Cards with icon, title, definition, unlocked/in-progress state and progress.
- Example milestone concepts are placeholders, not committed product rules.
- Unlock state comes from backend; icon/colour must not be sole signal.
- Empty state explains how to earn milestones.

### 8. Profile
- Display name, email (editable only if auth supports it), learning goal.
- Read-only snapshot: level, best WPM, streak, member since.
- Field validation, loading/success/error save states.
- Warn before navigating away with unsaved edits.

### 9. Settings
- Theme: light/dark/system; apply immediately and persist.
- Text size only if actual scalable typography is implemented.
- Typing preferences: live WPM, accuracy feedback, sounds, current-character highlight.
- Save-history preference.
- Reset preferences should confirm if multiple values change.
- Hide or clearly disable unimplemented controls.
- Respect reduced-motion preference.

### 10. Help & support
- Keyboard-accessible FAQ accordion.
- Form fields: topic and message; required validation and sensible max length.
- Disable duplicate submit while loading; preserve message on error.
- Show success only after backend confirmation.

### 11. Authentication
- Sign in/create account modes; email/password; forgot-password route.
- Required/email/password validation based on actual auth provider.
- Async loading; prevent duplicate requests.
- General errors must not reveal whether an email exists.
- Terms/Privacy links must be real URLs.
- Guest mode only if approved and supported.

### 12. Password reset
- Email field, send reset, back to sign in.
- Privacy-preserving confirmation (do not reveal account existence).
- Loading, validation, success and retryable failure states.

### 13. Optional upgrade
- Exclude from core V1 unless monetization is approved.
- Never invent price, payment provider, urgency or subscription claims.
- Keep feature/price content configurable.

## Interaction states
Every control: default, hover, focus-visible, pressed, disabled; async controls also loading/success/error.  
Forms: placeholder, autofill, read-only, required, invalid, valid, disabled. Keep visible labels; associate helper/error text programmatically.  
Dialogs: accessible title/description, focus management, Escape policy, focus restoration.  
Toasts: polite status announcement; never sole channel for critical error.  
All links: default, hover, focus, visited/active as relevant.

## API integration
Copilot must inspect the repository/backend before implementing. Do not invent endpoint paths, DTO fields, or successful responses. Suggested service boundaries:
- auth, dashboard, lessons, sessions, reports, achievements, profile, preferences, support.

Use typed request/response models, centralized API config/error handling, cancellation where useful, pagination for long histories, and idempotent session finalization if supported. Keep mock fixtures separate from production services. Never mix hardcoded demo values into real API UI.

## Suggested frontend organization
Adapt to existing structure; do not overwrite without inspection.
```text
src/
  app/ (router, providers)
  layouts/ (AppShell, AuthLayout)
  pages/ (Dashboard, Practice, Lessons, Tests, Results, Reports,
          Achievements, Profile, Settings, Help, Auth, ForgotPassword)
  components/ (navigation, forms, feedback, charts, practice)
  features/ (auth, sessions, lessons, reports, profile, settings)
  services/
  hooks/
  types/
  styles/ (tokens.css, globals.css)
```

## Implementation sequence
1. Inspect existing repo, framework, routes, styles, dependencies, backend contracts and tests.
2. Report current implementation and proposed file changes; preserve working code.
3. Add semantic tokens, typography, theme provider, responsive shell.
4. Build shared primitives and state variants.
5. Build Dashboard with loading/empty/error.
6. Build reusable session engine and Practice; verify formulas with product owner.
7. Build Tests and Results on the shared engine.
8. Build Lessons, Reports, Achievements.
9. Build Profile, Settings, Help.
10. Add Auth/reset only to match real auth backend.
11. Add route guards, unsaved-work protections, accessibility and responsive QA.
12. Add tests; remove mock data from production paths; document API gaps.

## Copilot rules
- Work incrementally, not as one uncontrolled rewrite.
- Before edits, state files and scope.
- Preserve existing conventions and components.
- Ask when API contracts or product decisions are missing.
- Every visible control must work, be disabled with explanation, or be removed.
- No fake success; do not claim completion without tests.
- After each milestone report changed files, checks run, failures, and remaining work.

## Acceptance criteria
- [ ] All approved routes exist and map to prototype.
- [ ] Responsive shell and active navigation work.
- [ ] Typography and semantic tokens are consistently applied.
- [ ] Light/dark theme works and persists.
- [ ] Every control has proper states and keyboard focus.
- [ ] Practice state renderer handles correct/incorrect/current/pending/corrected/missed.
- [ ] WPM and accuracy formulas documented and unit-tested.
- [ ] Timer, finish, restart, expiry and abandon flows work.
- [ ] Results match finalized session data.
- [ ] Reports show real data, accessible chart summaries and empty/error states.
- [ ] Forms validate and preserve values on errors.
- [ ] WCAG 2.2 AA contrast and keyboard review completed.
- [ ] 320, 375, 640, 768, 1024, 1280 and 1536px layouts checked.
- [ ] Unit/component/integration tests, typecheck, lint and build pass.

## Decisions to confirm
1. Guest mode or mandatory authentication?
2. Final lesson curriculum and progression?
3. Gross/net WPM and error penalty?
4. Accuracy denominator and correction handling?
5. Paste policy for each mode?
6. Pause/resume and session recovery?
7. Test durations?
8. Achievements in V1?
9. Export needs?
10. Upgrade/paid plan in scope?
11. Auth provider and actual API contracts?
12. Supported languages and keyboard layouts?

**Priority:** implement core Dashboard → Practice/Test → Results → Reports first. Keep unresolved features configurable and do not let optional scope block the core flow.
